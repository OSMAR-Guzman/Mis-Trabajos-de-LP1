
package clases;

/**
 *
 * @author SAMSUNG
 */
public class Funciones {
    
}
